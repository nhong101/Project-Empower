def careerInfo(a, b, c):
      print(str(a))
      print("Average post undergraduate salary: ", "$" + str(b))
      print("Projected job growth in the next decade: "+ str(c) + "%")
def bestColleges(a, b, c, d): 
  print("The Best Colleges for" , str(a), "are: ", str(b) + ",", str(c) + ",", str(d) )

def avgTuition (a):
 print("The average tuition for your income is:" , "$"+ str(a))


majorChoice = ""
collegemajorInfo = ""
isQuit = "false"
isQuit2 = "false"
householdIncome = 0
print("Welcome to the College & Career Database!")
while isQuit == "false":  #loops the menu
  print("1. Calculate Tuition")
  print("2. Learn more about careers postundergrad")
  print("3. Best Colleges for your Major")
  print("4. Quit Menu")
  userInput1 = int(input("Please select one of the options above: \n"))
  if userInput1 == 1:
    print("1. $0 - $30,000")
    print("2. $30,001 - $48,000")
    print("3. $48,001 - $75,000")
    print("4. $75,001 - $110,000")
    householdIncome = int(input("What is your annual household income?\n"))
    print("1. Private/ Ivy League University")
    print("2. Public University")
    print("3. Community College")
    collegeChoice = int(input("What institution do you plan to attend?\n"))
    if collegeChoice == 1:
      if householdIncome == 1:
        avgTuition(2000)
      if householdIncome == 2:
        avgTuition(5000)
      if householdIncome == 3:
        avgTuition(4000)
      if householdIncome == 4:
        avgTuition(1600)
    if collegeChoice == 2:
      if householdIncome == 1:
        avgTuition(6800)
      if householdIncome == 2:
        avgTuition(8000)
      if householdIncome == 3:
        avgTuition(10000)
      if householdIncome == 4:
        avgTuition(16500)
    if collegeChoice == 3:
      if householdIncome == 1:
        avgTuition(3000)
      if householdIncome == 2:
        avgTuition(3200)
      if householdIncome == 3:
        avgTuition(5900)
      if householdIncome == 4:
        avgTuition(6900)
  if userInput1 == 2:
    print("A. Computer Science")
    print("B. Business")
    print("C. Engineering")
    print("D. Medicine")
    print("E. Law")
    print("F. Education")
    userInput = str(input("What major would you like more details on?\n"))
    if userInput == "A":
      careerInfo("Computer Science", "86000", "21")
    if userInput == "B":
      careerInfo("Business", "65000", "7")
    if userInput == "C":
      careerInfo("Engineering", "70000", "4")
    if userInput == "D":
      careerInfo("Medicine", "200000", "13")
    if userInput == "E":
      careerInfo("Law", "180000", "10")
    if userInput == "F":
      careerInfo("Education/Teaching", "45000", "8")
  if userInput1 == 3:
    print("A. Computer Science")
    print("B. Business")
    print("C. Engineering")
    print("D. Medicine")
    print("E. Law")
    print("F. Education")
    userInput3 = str(input("What major would you like to see the major colleges of?\n"))
    if userInput3 == "A":
      bestColleges("Computer Science", "MIT", "Stanford", "UC Berkely")
    if userInput3 == "B":
      bestColleges("Business","UPEN", "MIT", "UC Berkely")
    if userInput3 == "C":
      bestColleges("Engineering", "MIT", "Stanford", "UC Berkely")
    if userInput3 == "D":
      bestColleges("Medicine", "Harvard", "John Hopkins", "UPEN")
    if userInput3 == "E":
      bestColleges("Law", "Stanford", "Yale", "UChicago")
    if userInput3 == "F":
      bestColleges("Education", "Elon", "Brown", "Princeton")
  if userInput1 == 4:
    isQuit = "true"